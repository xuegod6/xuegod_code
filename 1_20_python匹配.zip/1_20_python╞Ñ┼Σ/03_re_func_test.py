# -*- coding: utf-8 -*-
# @Time    : 2019/2/25 22:23
# @Author  : for 
# @File    : 03_re_func_test.py
# @Software: PyCharm
import re
import re
# temp = '''first line
# second line
# third line
# '''
# pat = re.compile('.+',re.S)
#
# result = pat.match(temp)
#
# if result:
#     print(result.group())

# temp = 'hello world 123'
#
# ret = re.match(r'\d+',temp)
# if ret:
#     print(ret.group())


# temp = 'hello 123 world 123'
#
# ret = re.search(r'\d+',temp)
# if ret:
#     print(ret.group())

# string = 'he123llo world'
# print(re.sub(r'\d','0',string))


