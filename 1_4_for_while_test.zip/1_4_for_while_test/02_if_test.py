# -*- coding: utf-8 -*-
# @Time : 2019/1/4 21:17 
# @Author : for 
# @File : 02_if_test.py
# @Software: PyCharm
age = 18

if age >= 6:
    print('你已经长大了')
elif age >= 18:
    print('孩子 你还小')
else:
    print('hello 小baby 叔叔带你去……')