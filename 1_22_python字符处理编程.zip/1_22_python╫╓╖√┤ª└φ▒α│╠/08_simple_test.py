# -*- coding: utf-8 -*-
# @Time    : 2019/2/28 22:16
# @Author  : for 
# @File    : 08_simple_test.py
# @Software: PyCharm
import random

data = [random.randrange(1,30) for i in range(30)]
print(data)