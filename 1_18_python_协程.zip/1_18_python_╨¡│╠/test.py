a = ['a','b','c']

for i in enumerate(a,1):
    print(i)