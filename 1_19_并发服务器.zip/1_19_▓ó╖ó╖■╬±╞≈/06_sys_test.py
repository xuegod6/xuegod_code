# -*- coding: utf-8 -*-
# @Time    : 2019/2/23 22:17
# @Author  : for 
# @File    : 06_sys_test.py
# @Software: PyCharm
import sys
print('input you name ')
name  = sys.stdin.readline()
print('hello',name)

print(dir(sys))