# -*- coding: utf-8 -*-
# @Time    : 2019/2/23 19:57
# @Author  : for 
# @File    : test.py
# @Software: PyCharm
import sys
print('Plase input your name: ')
name = sys.stdin.readline()
print('Hello ', name)